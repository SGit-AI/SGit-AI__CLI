# ═══════════════════════════════════════════════════════════════════════════════
# Safe_Str__Git__Author_Line - Git author/committer line
# Format: "Name <email> timestamp timezone"
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.primitives.core.Safe_Str import Safe_Str


class Safe_Str__Git__Author_Line(Safe_Str):              # "Name <email> 1234567890 +0000"
    max_length      = 1024                               # Reasonable limit
    allow_empty     = True
    trim_whitespace = True
