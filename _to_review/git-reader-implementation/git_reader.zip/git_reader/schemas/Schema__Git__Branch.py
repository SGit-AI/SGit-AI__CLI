# ═══════════════════════════════════════════════════════════════════════════════
# Schema__Git__Branch - Branch reference
# Contains branch name and tip commit SHA
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.Type_Safe                                               import Type_Safe
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.git.safe_str.Safe_Str__Git__Branch   import Safe_Str__Git__Branch


class Schema__Git__Branch(Type_Safe):                    # Branch reference
    name       : Safe_Str__Git__Branch                   # Branch name (validated)
    commit_sha : Safe_Str__SHA1                          # Tip commit SHA
