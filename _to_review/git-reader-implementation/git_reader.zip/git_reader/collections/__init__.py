# ═══════════════════════════════════════════════════════════════════════════════
# Git Collections - Type-safe collection types for Git operations
# ═══════════════════════════════════════════════════════════════════════════════

from git_reader.collections.List__Git__SHAs           import List__Git__SHAs
from git_reader.collections.List__Git__Branches       import List__Git__Branches
from git_reader.collections.List__Git__Commits        import List__Git__Commits
from git_reader.collections.List__Git__File_Changes   import List__Git__File_Changes
from git_reader.collections.Dict__Git__Files__By_Path import Dict__Git__Files__By_Path
