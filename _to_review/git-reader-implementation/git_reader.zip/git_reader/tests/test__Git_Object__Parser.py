# ═══════════════════════════════════════════════════════════════════════════════
# Test__Git_Object__Parser - Tests for Git object parsing
# Uses real git repository - no mocks
# ═══════════════════════════════════════════════════════════════════════════════

import unittest
from pathlib                                                                               import Path
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1         import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1__Short  import Safe_Str__SHA1__Short
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path          import Safe_Str__File__Path
from git_reader.Git_Object__Reader                                                         import Git_Object__Reader
from git_reader.Git_Object__Parser                                                         import Git_Object__Parser
from git_reader.enums.Enum__Git__Object_Type                                               import Enum__Git__Object_Type
from git_reader.schemas.Schema__Git__Commit                                                import Schema__Git__Commit
from git_reader.schemas.Schema__Git__Author_Info                                           import Schema__Git__Author_Info
from git_reader.schemas.Schema__Git__Tree_Entry                                            import Schema__Git__Tree_Entry


class test__Git_Object__Parser(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.test_repo_path = cls.find_git_repo()
        cls.git_dir        = Safe_Str__File__Path(str(cls.test_repo_path / ".git"))
        cls.reader         = Git_Object__Reader(git_dir=cls.git_dir)
        cls.parser         = Git_Object__Parser(object_reader=cls.reader)
        cls.head_sha       = cls.get_head_sha(cls.test_repo_path)

    @classmethod
    def find_git_repo(cls) -> Path:
        current = Path(__file__).resolve()
        for parent in [current] + list(current.parents):
            if (parent / ".git").exists():
                return parent
        raise RuntimeError("No git repository found in parent directories")

    @classmethod
    def get_head_sha(cls, repo_path: Path) -> Safe_Str__SHA1:
        head_path = repo_path / ".git" / "HEAD"
        content   = head_path.read_text().strip()
        if content.startswith('ref: '):
            ref_path = content[5:]
            sha_path = repo_path / ".git" / ref_path
            return Safe_Str__SHA1(sha_path.read_text().strip())
        return Safe_Str__SHA1(content)

    def test__init__(self):
        with Git_Object__Parser() as _:
            assert type(_)              is Git_Object__Parser

    def test__parse_commit(self):
        result = self.reader.read_object(self.head_sha)
        assert result                   is not None

        obj_type, content = result
        assert obj_type                 == Enum__Git__Object_Type.COMMIT

        commit = self.parser.parse_commit(self.head_sha, content)

        assert type(commit)             is Schema__Git__Commit
        assert type(commit.sha)         is Safe_Str__SHA1
        assert type(commit.sha_short)   is Safe_Str__SHA1__Short
        assert str(commit.sha)          == str(self.head_sha)
        assert str(commit.sha_short)    == str(self.head_sha)[:7]
        assert len(str(commit.tree_sha)) == 40
        assert type(commit.author)      is Schema__Git__Author_Info
        assert type(commit.committer)   is Schema__Git__Author_Info

    def test__parse_commit__author_info(self):
        result   = self.reader.read_object(self.head_sha)
        _, content = result

        commit   = self.parser.parse_commit(self.head_sha, content)

        assert commit.author.name       != ''
        assert commit.author.timestamp  > 0
        assert commit.author.tz_offset  != ''

    def test__parse_author_line(self):
        line = "John Doe <john@example.com> 1234567890 +0000"
        info = self.parser.parse_author_line(line)

        assert type(info)               is Schema__Git__Author_Info
        assert str(info.name)           == "John Doe"
        assert str(info.email)          == "john@example.com"
        assert int(info.timestamp)      == 1234567890
        assert str(info.tz_offset)      == "+0000"

    def test__parse_tree(self):
        result = self.reader.read_object(self.head_sha)
        _, content = result

        commit      = self.parser.parse_commit(self.head_sha, content)
        tree_result = self.reader.read_object(commit.tree_sha)

        assert tree_result              is not None

        tree_type, tree_content = tree_result
        assert tree_type                == Enum__Git__Object_Type.TREE

        entries = self.parser.parse_tree(tree_content)

        assert type(entries)            is list
        assert len(entries)             > 0

        for entry in entries:
            assert type(entry)          is Schema__Git__Tree_Entry
            assert len(str(entry.sha))  == 40
            assert str(entry.mode)      in ('40000', '100644', '100755', '120000')

    def test__flatten_tree(self):
        result   = self.reader.read_object(self.head_sha)
        _, content = result

        commit      = self.parser.parse_commit(self.head_sha, content)
        flat_files  = self.parser.flatten_tree(commit.tree_sha)

        assert type(flat_files)         is dict
        assert len(flat_files)          > 0

        for path, sha in flat_files.items():
            assert type(path)           is str
            assert len(str(sha))        == 40


if __name__ == '__main__':
    unittest.main()
