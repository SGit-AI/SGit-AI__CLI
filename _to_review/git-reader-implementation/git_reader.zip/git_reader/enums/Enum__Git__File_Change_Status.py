# ═══════════════════════════════════════════════════════════════════════════════
# Enum__Git__File_Change_Status - File change types in a commit
# A=Added, M=Modified, D=Deleted
# ═══════════════════════════════════════════════════════════════════════════════

from enum import Enum


class Enum__Git__File_Change_Status(str, Enum):          # File change types
    ADDED    = 'A'
    MODIFIED = 'M'
    DELETED  = 'D'
