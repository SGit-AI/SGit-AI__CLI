# ═══════════════════════════════════════════════════════════════════════════════
# Schema__Git__Tree_Entry - Single entry in a git tree
# Contains mode, name, and SHA of the entry (blob or subtree)
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.Type_Safe                                               import Type_Safe
from osbot_utils.type_safe.primitives.core.Safe_Str                                import Safe_Str
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from git_reader.primitives.Safe_Str__Git__Tree_Path                                import Safe_Str__Git__Tree_Path


class Schema__Git__Tree_Entry(Type_Safe):                # Single tree entry
    mode : Safe_Str                                      # File mode (100644, 40000, etc)
    name : Safe_Str__Git__Tree_Path                      # File/directory name
    sha  : Safe_Str__SHA1                                # SHA of blob or subtree


# ═══════════════════════════════════════════════════════════════════════════════
# Tree Entry Mode Constants
# ═══════════════════════════════════════════════════════════════════════════════

GIT_MODE__TREE       = '40000'                           # Directory/subtree
GIT_MODE__BLOB       = '100644'                          # Regular file
GIT_MODE__EXECUTABLE = '100755'                          # Executable file
GIT_MODE__SYMLINK    = '120000'                          # Symbolic link
