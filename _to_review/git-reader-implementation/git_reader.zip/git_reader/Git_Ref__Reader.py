# ═══════════════════════════════════════════════════════════════════════════════
# Git_Ref__Reader - Read Git references from .git/refs and HEAD
# Handles symbolic refs, packed-refs, and branch enumeration
# ═══════════════════════════════════════════════════════════════════════════════

from pathlib                                                                       import Path
from typing                                                                        import Optional, List, Dict
from osbot_utils.type_safe.Type_Safe                                               import Type_Safe
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path  import Safe_Str__File__Path
from osbot_utils.type_safe.primitives.domains.git.safe_str.Safe_Str__Git__Branch   import Safe_Str__Git__Branch
from git_reader.schemas.Schema__Git__Branch                                        import Schema__Git__Branch


class Git_Ref__Reader(Type_Safe):                        # Read refs from .git
    git_dir : Safe_Str__File__Path                       # Path to .git folder

    def head_sha(self) -> Optional[Safe_Str__SHA1]:
        head_path = Path(str(self.git_dir)) / "HEAD"

        if head_path.exists() is False:
            return None

        head_content = head_path.read_text().strip()

        if head_content.startswith('ref: '):            # Symbolic reference
            ref_path = head_content[5:]                 # e.g., "refs/heads/main"
            return self.resolve_ref(ref_path)
        else:                                           # Detached HEAD (direct SHA)
            return Safe_Str__SHA1(head_content)

    def resolve_ref(self, ref_path: str) -> Optional[Safe_Str__SHA1]:
        ref_file = Path(str(self.git_dir)) / ref_path

        if ref_file.exists():
            sha = ref_file.read_text().strip()
            return Safe_Str__SHA1(sha)

        packed_refs = self.read_packed_refs()           # Try packed-refs
        if ref_path in packed_refs:
            return packed_refs[ref_path]

        return None

    def read_packed_refs(self) -> Dict[str, Safe_Str__SHA1]:
        packed_refs_path = Path(str(self.git_dir)) / "packed-refs"
        result           = {}

        if packed_refs_path.exists() is False:
            return result

        for line in packed_refs_path.read_text().splitlines():
            line = line.strip()

            if line == '' or line.startswith('#') or line.startswith('^'):
                continue

            parts = line.split(' ', 1)
            if len(parts) == 2:
                sha, ref = parts
                result[ref] = Safe_Str__SHA1(sha)

        return result

    def branch_names(self) -> List[Safe_Str__Git__Branch]:
        branches   = []
        heads_path = Path(str(self.git_dir)) / "refs" / "heads"

        if heads_path.exists():
            branches.extend(self.collect_branches_recursive(heads_path, ''))

        packed_refs = self.read_packed_refs()           # Also check packed-refs
        for ref_path in packed_refs.keys():
            if ref_path.startswith('refs/heads/'):
                branch_name = ref_path[11:]             # Remove "refs/heads/"
                if branch_name not in [str(b) for b in branches]:
                    branches.append(Safe_Str__Git__Branch(branch_name))

        return branches

    def collect_branches_recursive(self                ,
                                   base_path : Path    ,
                                   prefix    : str     ) -> List[Safe_Str__Git__Branch]:
        branches = []

        for item in base_path.iterdir():
            if item.is_file():
                name = f"{prefix}{item.name}" if prefix else item.name
                branches.append(Safe_Str__Git__Branch(name))
            elif item.is_dir():
                sub_prefix = f"{prefix}{item.name}/" if prefix else f"{item.name}/"
                branches.extend(self.collect_branches_recursive(item, sub_prefix))

        return branches

    def branches(self) -> List[Schema__Git__Branch]:
        result       = []
        branch_names = self.branch_names()

        for name in branch_names:
            ref_path = f"refs/heads/{name}"
            sha      = self.resolve_ref(ref_path)

            if sha:
                result.append(Schema__Git__Branch(name       = name,
                                                  commit_sha = sha ))

        return result

    def branch_sha(self, name: Safe_Str__Git__Branch) -> Optional[Safe_Str__SHA1]:
        ref_path = f"refs/heads/{name}"
        return self.resolve_ref(ref_path)
