# ═══════════════════════════════════════════════════════════════════════════════
# Git_Object__Reader - Low-level Git object reading from .git/objects
# Handles loose objects and packfiles
# ═══════════════════════════════════════════════════════════════════════════════

import zlib
import struct
from pathlib                                                                       import Path
from typing                                                                        import Optional, Tuple
from osbot_utils.type_safe.Type_Safe                                               import Type_Safe
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path  import Safe_Str__File__Path
from git_reader.enums.Enum__Git__Object_Type                                       import Enum__Git__Object_Type


class Git_Object__Reader(Type_Safe):                     # Low-level object access
    git_dir : Safe_Str__File__Path                       # Path to .git folder

    def read_object(self, sha: Safe_Str__SHA1) -> Optional[Tuple[Enum__Git__Object_Type, bytes]]:
        result = self.read_loose_object(sha)             # Try loose object first
        if result:
            return result
        return self.read_packed_object(sha)              # Fall back to packfiles

    def read_loose_object(self, sha: Safe_Str__SHA1) -> Optional[Tuple[Enum__Git__Object_Type, bytes]]:
        sha_str  = str(sha)
        obj_path = Path(str(self.git_dir)) / "objects" / sha_str[:2] / sha_str[2:]

        if obj_path.exists() is False:
            return None

        with open(obj_path, 'rb') as f:
            compressed = f.read()

        raw         = zlib.decompress(compressed)
        null_idx    = raw.index(b'\x00')
        header      = raw[:null_idx].decode('utf-8')
        obj_type, _ = header.split(' ', 1)
        content     = raw[null_idx + 1:]

        return (Enum__Git__Object_Type(obj_type), content)

    def read_packed_object(self, sha: Safe_Str__SHA1) -> Optional[Tuple[Enum__Git__Object_Type, bytes]]:
        pack_dir = Path(str(self.git_dir)) / "objects" / "pack"

        if pack_dir.exists() is False:
            return None

        sha_bytes = bytes.fromhex(str(sha))

        for idx_file in pack_dir.glob("*.idx"):
            pack_file = idx_file.with_suffix(".pack")
            offset    = self.find_in_pack_index(idx_file, sha_bytes)

            if offset is not None:
                return self.read_pack_object_at_offset(pack_file, offset, sha)

        return None

    def find_in_pack_index(self, idx_path: Path, sha_bytes: bytes) -> Optional[int]:
        with open(idx_path, "rb") as f:
            magic = f.read(4)
            if magic != b"\xfftOc":
                return None

            version = struct.unpack(">I", f.read(4))[0]
            if version != 2:
                return None

            fanout        = struct.unpack(">256I", f.read(256 * 4))
            total_objects = fanout[255]

            first_byte       = sha_bytes[0]
            start            = fanout[first_byte - 1] if first_byte > 0 else 0
            end              = fanout[first_byte]
            sha_table_offset = 1032

            while start < end:
                mid = (start + end) // 2
                f.seek(sha_table_offset + mid * 20)
                entry_sha = f.read(20)

                if entry_sha == sha_bytes:
                    offset_table = sha_table_offset + total_objects * 20 + total_objects * 4
                    f.seek(offset_table + mid * 4)
                    offset = struct.unpack(">I", f.read(4))[0]

                    if offset & 0x80000000:
                        large_offset_table = offset_table + total_objects * 4
                        large_idx          = offset & 0x7FFFFFFF
                        f.seek(large_offset_table + large_idx * 8)
                        offset = struct.unpack(">Q", f.read(8))[0]

                    return offset
                elif entry_sha < sha_bytes:
                    start = mid + 1
                else:
                    end = mid

            return None

    def read_pack_object_at_offset(self                  ,
                                   pack_path : Path      ,
                                   offset    : int       ,
                                   sha       : Safe_Str__SHA1) -> Optional[Tuple[Enum__Git__Object_Type, bytes]]:
        TYPE_MAP = {1: Enum__Git__Object_Type.COMMIT,
                    2: Enum__Git__Object_Type.TREE  ,
                    3: Enum__Git__Object_Type.BLOB  ,
                    4: Enum__Git__Object_Type.TAG   }

        with open(pack_path, "rb") as f:
            f.seek(offset)

            byte     = f.read(1)[0]
            obj_type = (byte >> 4) & 0x07
            size     = byte & 0x0F
            shift    = 4

            while byte & 0x80:
                byte   = f.read(1)[0]
                size  |= (byte & 0x7F) << shift
                shift += 7

            if obj_type == 6:                            # OFS_DELTA
                byte        = f.read(1)[0]
                base_offset = byte & 0x7F
                while byte & 0x80:
                    byte         = f.read(1)[0]
                    base_offset  = ((base_offset + 1) << 7) | (byte & 0x7F)

                delta_data           = zlib.decompress(f.read())
                base_type, base_data = self.read_pack_object_at_offset(pack_path, offset - base_offset, sha)
                return (base_type, self.apply_delta(base_data, delta_data))

            elif obj_type == 7:                          # REF_DELTA
                base_sha             = Safe_Str__SHA1(f.read(20).hex())
                delta_data           = zlib.decompress(f.read())
                base_result          = self.read_object(base_sha)
                if base_result is None:
                    return None
                base_type, base_data = base_result
                return (base_type, self.apply_delta(base_data, delta_data))

            else:                                        # Regular object
                data = zlib.decompress(f.read())
                return (TYPE_MAP.get(obj_type), data)

    def apply_delta(self, base: bytes, delta: bytes) -> bytes:
        def read_varint(data: bytes, pos: int) -> Tuple[int, int]:
            result = 0
            shift  = 0
            while True:
                byte    = data[pos]
                pos    += 1
                result |= (byte & 0x7F) << shift
                if not (byte & 0x80):
                    break
                shift += 7
            return result, pos

        pos     = 0
        _, pos  = read_varint(delta, pos)
        _, pos  = read_varint(delta, pos)

        result = bytearray()

        while pos < len(delta):
            cmd  = delta[pos]
            pos += 1

            if cmd & 0x80:                               # Copy instruction
                copy_offset = 0
                copy_size   = 0

                if cmd & 0x01: copy_offset |= delta[pos]; pos += 1
                if cmd & 0x02: copy_offset |= delta[pos] << 8; pos += 1
                if cmd & 0x04: copy_offset |= delta[pos] << 16; pos += 1
                if cmd & 0x08: copy_offset |= delta[pos] << 24; pos += 1

                if cmd & 0x10: copy_size |= delta[pos]; pos += 1
                if cmd & 0x20: copy_size |= delta[pos] << 8; pos += 1
                if cmd & 0x40: copy_size |= delta[pos] << 16; pos += 1

                if copy_size == 0:
                    copy_size = 0x10000

                result.extend(base[copy_offset:copy_offset + copy_size])

            elif cmd:                                    # Insert instruction
                result.extend(delta[pos:pos + cmd])
                pos += cmd

        return bytes(result)
