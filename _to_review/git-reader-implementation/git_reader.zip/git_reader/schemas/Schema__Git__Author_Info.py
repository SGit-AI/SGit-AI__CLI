# ═══════════════════════════════════════════════════════════════════════════════
# Schema__Git__Author_Info - Parsed author/committer information
# Contains name, email, timestamp, and timezone offset
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.Type_Safe import Type_Safe
from osbot_utils.type_safe.primitives.core.Safe_Str  import Safe_Str
from osbot_utils.type_safe.primitives.core.Safe_UInt import Safe_UInt


class Schema__Git__Author_Info(Type_Safe):               # Parsed author/committer
    name      : Safe_Str                                 # Display name
    email     : Safe_Str                                 # Email address
    timestamp : Safe_UInt                                # Unix timestamp (seconds)
    tz_offset : Safe_Str                                 # "+0000" format
