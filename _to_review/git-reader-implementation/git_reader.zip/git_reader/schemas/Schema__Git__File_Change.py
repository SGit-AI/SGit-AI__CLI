# ═══════════════════════════════════════════════════════════════════════════════
# Schema__Git__File_Change - Single file change in a commit
# Contains path and status (Added/Modified/Deleted)
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.Type_Safe                           import Type_Safe
from git_reader.enums.Enum__Git__File_Change_Status            import Enum__Git__File_Change_Status
from git_reader.primitives.Safe_Str__Git__Tree_Path            import Safe_Str__Git__Tree_Path


class Schema__Git__File_Change(Type_Safe):               # Single file change
    path   : Safe_Str__Git__Tree_Path                    # File path in repo
    status : Enum__Git__File_Change_Status               # A/M/D
