# ═══════════════════════════════════════════════════════════════════════════════
# Test__Git_Repo__Reader__Service - Tests for high-level Git repository reader
# Uses real git repository - no mocks
# ═══════════════════════════════════════════════════════════════════════════════

import unittest
from pathlib                                                                               import Path
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1         import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1__Short  import Safe_Str__SHA1__Short
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path          import Safe_Str__File__Path
from osbot_utils.type_safe.primitives.domains.git.safe_str.Safe_Str__Git__Branch           import Safe_Str__Git__Branch
from git_reader.Git_Repo__Reader__Service                                                  import Git_Repo__Reader__Service
from git_reader.schemas.Schema__Git__Branch                                                import Schema__Git__Branch
from git_reader.schemas.Schema__Git__Commit                                                import Schema__Git__Commit
from git_reader.schemas.Schema__Git__Commit_Summary                                        import Schema__Git__Commit_Summary
from git_reader.schemas.Schema__Git__File_Change                                           import Schema__Git__File_Change
from git_reader.enums.Enum__Git__File_Change_Status                                        import Enum__Git__File_Change_Status


class test__Git_Repo__Reader__Service(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.test_repo_path = cls.find_git_repo()
        cls.service        = Git_Repo__Reader__Service(
                                 repo_path = Safe_Str__File__Path(str(cls.test_repo_path)))

    @classmethod
    def find_git_repo(cls) -> Path:
        current = Path(__file__).resolve()
        for parent in [current] + list(current.parents):
            if (parent / ".git").exists():
                return parent
        raise RuntimeError("No git repository found in parent directories")

    def test__init__(self):
        service = Git_Repo__Reader__Service(
                      repo_path = Safe_Str__File__Path(str(self.test_repo_path)))

        assert type(service)                   is Git_Repo__Reader__Service
        assert service.git_dir                 != ''
        assert service.object_reader           is not None
        assert service.object_parser           is not None
        assert service.ref_reader              is not None

    # ═══════════════════════════════════════════════════════════════════════════════
    # Branch Operations
    # ═══════════════════════════════════════════════════════════════════════════════

    def test__branches(self):
        branches = self.service.branches()

        assert type(branches)                  is list
        assert len(branches)                   > 0

        for branch in branches:
            assert type(branch)                is Schema__Git__Branch
            assert type(branch.name)           is Safe_Str__Git__Branch
            assert type(branch.commit_sha)     is Safe_Str__SHA1

    def test__branch_names(self):
        branch_names = self.service.branch_names()

        assert type(branch_names)              is list
        assert len(branch_names)               > 0

        for name in branch_names:
            assert type(name)                  is Safe_Str__Git__Branch

    # ═══════════════════════════════════════════════════════════════════════════════
    # HEAD Operations
    # ═══════════════════════════════════════════════════════════════════════════════

    def test__head_sha(self):
        sha = self.service.head_sha()

        assert sha                             is not None
        assert type(sha)                       is Safe_Str__SHA1
        assert len(str(sha))                   == 40

    def test__head_commit(self):
        summary = self.service.head_commit()

        assert summary                         is not None
        assert type(summary)                   is Schema__Git__Commit_Summary
        assert type(summary.commit)            is Schema__Git__Commit
        assert type(summary.files_changed)     is list

    # ═══════════════════════════════════════════════════════════════════════════════
    # Commit Operations
    # ═══════════════════════════════════════════════════════════════════════════════

    def test__commit(self):
        sha    = self.service.head_sha()
        commit = self.service.commit(sha)

        assert commit                          is not None
        assert type(commit)                    is Schema__Git__Commit
        assert type(commit.sha)                is Safe_Str__SHA1
        assert type(commit.sha_short)          is Safe_Str__SHA1__Short
        assert str(commit.sha)                 == str(sha)
        assert str(commit.sha_short)           == str(sha)[:7]
        assert len(str(commit.tree_sha))       == 40
        assert commit.message                  != ''

    def test__commit__sha_short(self):
        sha    = self.service.head_sha()
        commit = self.service.commit(sha)

        assert str(commit.sha_short)           == str(commit.sha)[:7]  # sha_short derived correctly
        assert len(str(commit.sha_short))      == 7

    def test__commits__default(self):
        commits = self.service.commits()

        assert type(commits)                   is list
        assert len(commits)                    > 0
        assert len(commits)                    <= 10                    # Default depth

        for commit in commits:
            assert type(commit)                is Schema__Git__Commit

    def test__commits__with_depth(self):
        commits = self.service.commits(depth=3)

        assert len(commits)                    <= 3

    def test__commits__with_branch(self):
        branches = self.service.branch_names()
        assert len(branches)                   > 0

        commits = self.service.commits(branch=branches[0], depth=5)

        assert type(commits)                   is list
        assert len(commits)                    <= 5

    def test__commits__follows_parent_chain(self):
        commits = self.service.commits(depth=5)

        if len(commits) > 1:
            for i in range(len(commits) - 1):
                current_commit = commits[i]
                next_commit    = commits[i + 1]

                if len(current_commit.parent_shas) > 0:  # Current's parent should be next
                    assert str(current_commit.parent_shas[0]) == str(next_commit.sha)

    # ═══════════════════════════════════════════════════════════════════════════════
    # File Change Detection
    # ═══════════════════════════════════════════════════════════════════════════════

    def test__files_changed(self):
        sha     = self.service.head_sha()
        changes = self.service.files_changed(sha)

        assert type(changes)                   is list

        for change in changes:
            assert type(change)                is Schema__Git__File_Change
            assert str(change.path)            != ''
            assert change.status               in Enum__Git__File_Change_Status

    def test__files_changed__status_values(self):
        sha     = self.service.head_sha()
        changes = self.service.files_changed(sha)

        for change in changes:
            assert change.status.value         in ('A', 'M', 'D')

    def test__head_commit__includes_files_changed(self):
        summary = self.service.head_commit()

        assert summary.files_changed           is not None
        assert type(summary.files_changed)     is list

        for change in summary.files_changed:
            assert type(change)                is Schema__Git__File_Change

    # ═══════════════════════════════════════════════════════════════════════════════
    # Integration Tests
    # ═══════════════════════════════════════════════════════════════════════════════

    def test__full_workflow(self):
        branches = self.service.branches()                             # 1. List branches
        assert len(branches)                   > 0

        head_sha = self.service.head_sha()                             # 2. Get HEAD
        assert head_sha                        is not None

        commits = self.service.commits(depth=3)                        # 3. Get commits
        assert len(commits)                    > 0

        summary = self.service.head_commit()                           # 4. Get HEAD commit summary
        assert summary                         is not None
        assert summary.commit.sha              == head_sha

    def test__commit_message_accessible(self):
        sha     = self.service.head_sha()
        commit  = self.service.commit(sha)

        message = commit.message
        assert message                         is not None
        first_line = str(message).split('\n')[0]                       # Should be able to get first line
        assert first_line                      != '' or str(message) == ''

    def test__author_info_accessible(self):
        sha    = self.service.head_sha()
        commit = self.service.commit(sha)

        assert commit.author.name              != '' or str(commit.author.name) == ''
        assert commit.author.timestamp         >= 0
        assert commit.committer.name           != '' or str(commit.committer.name) == ''


if __name__ == '__main__':
    unittest.main()
