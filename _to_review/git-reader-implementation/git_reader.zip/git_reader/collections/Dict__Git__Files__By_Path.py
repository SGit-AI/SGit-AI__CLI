# ═══════════════════════════════════════════════════════════════════════════════
# Dict__Git__Files__By_Path - Map file paths to blob SHAs
# Used for tree flattening and file change detection
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.type_safe_core.collections.Type_Safe__Dict              import Type_Safe__Dict
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from git_reader.primitives.Safe_Str__Git__Tree_Path                                import Safe_Str__Git__Tree_Path


class Dict__Git__Files__By_Path(Type_Safe__Dict):        # Path → Blob SHA mapping
    expected_key_type   = Safe_Str__Git__Tree_Path
    expected_value_type = Safe_Str__SHA1
