# ═══════════════════════════════════════════════════════════════════════════════
# Git Schemas - Type-safe data structures for Git objects
# ═══════════════════════════════════════════════════════════════════════════════

from git_reader.schemas.Schema__Git__Author_Info    import Schema__Git__Author_Info
from git_reader.schemas.Schema__Git__File_Change    import Schema__Git__File_Change
from git_reader.schemas.Schema__Git__Commit         import Schema__Git__Commit
from git_reader.schemas.Schema__Git__Branch         import Schema__Git__Branch
from git_reader.schemas.Schema__Git__Commit_Summary import Schema__Git__Commit_Summary
from git_reader.schemas.Schema__Git__Tree_Entry     import Schema__Git__Tree_Entry
from git_reader.schemas.Schema__Git__Tree_Entry     import GIT_MODE__TREE
from git_reader.schemas.Schema__Git__Tree_Entry     import GIT_MODE__BLOB
from git_reader.schemas.Schema__Git__Tree_Entry     import GIT_MODE__EXECUTABLE
from git_reader.schemas.Schema__Git__Tree_Entry     import GIT_MODE__SYMLINK
