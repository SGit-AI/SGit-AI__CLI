# ═══════════════════════════════════════════════════════════════════════════════
# Test__Git_Object__Reader - Tests for low-level Git object reading
# Uses real git repository - no mocks
# ═══════════════════════════════════════════════════════════════════════════════

import unittest
from pathlib                                                                       import Path
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path  import Safe_Str__File__Path
from git_reader.Git_Object__Reader                                                 import Git_Object__Reader
from git_reader.enums.Enum__Git__Object_Type                                       import Enum__Git__Object_Type


class test__Git_Object__Reader(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.test_repo_path = cls.find_git_repo()         # Find a real git repo
        cls.git_dir        = Safe_Str__File__Path(str(cls.test_repo_path / ".git"))
        cls.reader         = Git_Object__Reader(git_dir=cls.git_dir)
        cls.head_sha       = cls.get_head_sha(cls.test_repo_path)

    @classmethod
    def find_git_repo(cls) -> Path:
        current = Path(__file__).resolve()               # Walk up to find .git
        for parent in [current] + list(current.parents):
            if (parent / ".git").exists():
                return parent
        raise RuntimeError("No git repository found in parent directories")

    @classmethod
    def get_head_sha(cls, repo_path: Path) -> Safe_Str__SHA1:
        head_path = repo_path / ".git" / "HEAD"
        content   = head_path.read_text().strip()
        if content.startswith('ref: '):
            ref_path = content[5:]
            sha_path = repo_path / ".git" / ref_path
            return Safe_Str__SHA1(sha_path.read_text().strip())
        return Safe_Str__SHA1(content)

    def test__init__(self):
        with Git_Object__Reader() as _:
            assert type(_)          is Git_Object__Reader
            assert _.git_dir        == ''

    def test__read_object__commit(self):
        result = self.reader.read_object(self.head_sha)

        assert result              is not None
        assert type(result)        is tuple
        assert len(result)         == 2

        obj_type, content = result
        assert obj_type            == Enum__Git__Object_Type.COMMIT
        assert type(content)       is bytes
        assert b'tree '            in content
        assert b'author '          in content

    def test__read_object__nonexistent(self):
        fake_sha = Safe_Str__SHA1("a" * 40)
        result   = self.reader.read_object(fake_sha)

        assert result              is None

    def test__read_loose_object(self):
        result = self.reader.read_loose_object(self.head_sha)

        if result is not None:                           # Object might be in pack
            obj_type, content = result
            assert obj_type        in Enum__Git__Object_Type
            assert type(content)   is bytes

    def test__object_has_tree_reference(self):
        result = self.reader.read_object(self.head_sha)

        assert result              is not None
        obj_type, content = result

        text     = content.decode('utf-8')
        lines    = text.split('\n')
        tree_sha = None

        for line in lines:
            if line.startswith('tree '):
                tree_sha = line[5:]
                break

        assert tree_sha            is not None
        assert len(tree_sha)       == 40

        tree_result = self.reader.read_object(Safe_Str__SHA1(tree_sha))  # Read the tree
        assert tree_result         is not None
        assert tree_result[0]      == Enum__Git__Object_Type.TREE


if __name__ == '__main__':
    unittest.main()
