# ═══════════════════════════════════════════════════════════════════════════════
# List__Git__SHAs - Type-safe list of Git SHA-1 hashes
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.type_safe_core.collections.Type_Safe__List              import Type_Safe__List
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1


class List__Git__SHAs(Type_Safe__List):                  # List of commit SHAs
    expected_type = Safe_Str__SHA1
