# ═══════════════════════════════════════════════════════════════════════════════
# Git_Object__Parser - Parse raw git objects into Type_Safe schemas
# Handles commit, tree, and blob parsing
# ═══════════════════════════════════════════════════════════════════════════════

import re
from typing                                                                               import List, Dict
from osbot_utils.type_safe.Type_Safe                                                      import Type_Safe
from osbot_utils.type_safe.primitives.core.Safe_Str                                       import Safe_Str
from osbot_utils.type_safe.primitives.core.Safe_UInt                                      import Safe_UInt
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1        import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1__Short import Safe_Str__SHA1__Short
from git_reader.primitives.Safe_Str__Git__Commit_Message                                  import Safe_Str__Git__Commit_Message
from git_reader.primitives.Safe_Str__Git__Tree_Path                                       import Safe_Str__Git__Tree_Path
from git_reader.schemas.Schema__Git__Author_Info                                          import Schema__Git__Author_Info
from git_reader.schemas.Schema__Git__Commit                                               import Schema__Git__Commit
from git_reader.schemas.Schema__Git__Tree_Entry                                           import Schema__Git__Tree_Entry
from git_reader.schemas.Schema__Git__Tree_Entry                                           import GIT_MODE__TREE
from git_reader.Git_Object__Reader                                                        import Git_Object__Reader
from git_reader.enums.Enum__Git__Object_Type                                              import Enum__Git__Object_Type


class Git_Object__Parser(Type_Safe):                     # Parse objects to schemas
    object_reader : Git_Object__Reader                   # For reading nested objects

    def parse_commit(self                              ,
                     sha    : Safe_Str__SHA1           ,
                     content: bytes                    ) -> Schema__Git__Commit:
        text  = content.decode('utf-8', errors='replace')
        lines = text.split('\n')

        tree_sha    = Safe_Str__SHA1()
        parent_shas = []
        author      = Schema__Git__Author_Info()
        committer   = Schema__Git__Author_Info()
        msg_start   = 0

        for i, line in enumerate(lines):
            if line == '':
                msg_start = i + 1
                break
            if line.startswith('tree '):
                tree_sha = Safe_Str__SHA1(line[5:])
            elif line.startswith('parent '):
                parent_shas.append(Safe_Str__SHA1(line[7:]))
            elif line.startswith('author '):
                author = self.parse_author_line(line[7:])
            elif line.startswith('committer '):
                committer = self.parse_author_line(line[10:])

        message = Safe_Str__Git__Commit_Message('\n'.join(lines[msg_start:]).strip())

        return Schema__Git__Commit(sha         = sha                                ,
                                   sha_short   = Safe_Str__SHA1__Short(str(sha)[:7]),
                                   tree_sha    = tree_sha                           ,
                                   parent_shas = parent_shas                        ,
                                   author      = author                             ,
                                   committer   = committer                          ,
                                   message     = message                            )

    def parse_author_line(self, line: str) -> Schema__Git__Author_Info:
        pattern   = r'^(.+?)\s+<([^>]*)>\s+(\d+)\s+([+-]\d{4})$'
        match     = re.match(pattern, line)

        if match:
            return Schema__Git__Author_Info(name      = Safe_Str(match.group(1))      ,
                                            email     = Safe_Str(match.group(2))      ,
                                            timestamp = Safe_UInt(int(match.group(3))),
                                            tz_offset = Safe_Str(match.group(4))      )
        return Schema__Git__Author_Info()

    def parse_tree(self, content: bytes) -> List[Schema__Git__Tree_Entry]:
        entries = []
        pos     = 0

        while pos < len(content):
            space_idx = content.index(b' ', pos)         # Find space after mode
            mode      = content[pos:space_idx].decode('utf-8')

            null_idx  = content.index(b'\x00', space_idx)  # Find null after name
            name      = content[space_idx + 1:null_idx].decode('utf-8', errors='replace')

            sha_bytes = content[null_idx + 1:null_idx + 21]  # Read 20-byte SHA
            sha       = sha_bytes.hex()

            entries.append(Schema__Git__Tree_Entry(mode = Safe_Str(mode)                     ,
                                                   name = Safe_Str__Git__Tree_Path(name)     ,
                                                   sha  = Safe_Str__SHA1(sha)                ))
            pos = null_idx + 21

        return entries

    def flatten_tree(self                              ,
                     tree_sha : Safe_Str__SHA1         ,
                     prefix   : str = ''               ) -> Dict[str, Safe_Str__SHA1]:
        result      = {}
        tree_result = self.object_reader.read_object(tree_sha)

        if tree_result is None:
            return result

        obj_type, content = tree_result

        if obj_type != Enum__Git__Object_Type.TREE:
            return result

        entries = self.parse_tree(content)

        for entry in entries:
            path = f"{prefix}{entry.name}" if prefix == '' else f"{prefix}/{entry.name}"

            if entry.mode == GIT_MODE__TREE:             # Recurse into subdirectory
                subtree_files = self.flatten_tree(entry.sha, path)
                result.update(subtree_files)
            else:                                        # It's a file (blob)
                result[path] = entry.sha

        return result
