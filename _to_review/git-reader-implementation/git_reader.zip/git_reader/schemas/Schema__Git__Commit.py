# ═══════════════════════════════════════════════════════════════════════════════
# Schema__Git__Commit - Full commit data
# Contains SHA (full and short), tree, parents, author, committer, message
# ═══════════════════════════════════════════════════════════════════════════════

from typing                                                                               import List
from osbot_utils.type_safe.Type_Safe                                                      import Type_Safe
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1        import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1__Short import Safe_Str__SHA1__Short
from git_reader.primitives.Safe_Str__Git__Commit_Message                                  import Safe_Str__Git__Commit_Message
from git_reader.schemas.Schema__Git__Author_Info                                          import Schema__Git__Author_Info


class Schema__Git__Commit(Type_Safe):                    # Full commit data
    sha         : Safe_Str__SHA1                         # Full 40-char SHA
    sha_short   : Safe_Str__SHA1__Short                  # Short 7-char SHA (for display)
    tree_sha    : Safe_Str__SHA1                         # Tree object SHA
    parent_shas : List[Safe_Str__SHA1]                   # 0+ parent SHAs
    author      : Schema__Git__Author_Info               # Author details
    committer   : Schema__Git__Author_Info               # Committer details
    message     : Safe_Str__Git__Commit_Message          # Full message
