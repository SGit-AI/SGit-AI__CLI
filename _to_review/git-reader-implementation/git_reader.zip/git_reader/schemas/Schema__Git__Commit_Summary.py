# ═══════════════════════════════════════════════════════════════════════════════
# Schema__Git__Commit_Summary - Commit with files changed
# Combines commit details with list of file changes
# ═══════════════════════════════════════════════════════════════════════════════

from typing                                                   import List
from osbot_utils.type_safe.Type_Safe                          import Type_Safe
from git_reader.schemas.Schema__Git__Commit                   import Schema__Git__Commit
from git_reader.schemas.Schema__Git__File_Change              import Schema__Git__File_Change


class Schema__Git__Commit_Summary(Type_Safe):            # Commit with files changed
    commit        : Schema__Git__Commit                  # Commit details
    files_changed : List[Schema__Git__File_Change]       # Changed files
