# ═══════════════════════════════════════════════════════════════════════════════
# Enum__Git__Object_Type - Git object types
# commit, tree, blob, tag
# ═══════════════════════════════════════════════════════════════════════════════

from enum import Enum


class Enum__Git__Object_Type(str, Enum):                 # Git object types
    COMMIT = 'commit'
    TREE   = 'tree'
    BLOB   = 'blob'
    TAG    = 'tag'
