# ═══════════════════════════════════════════════════════════════════════════════
# Safe_Str__Git__Tree_Path - File/directory path within a git tree
# Used for file paths in tree entries
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.primitives.core.Safe_Str import Safe_Str


class Safe_Str__Git__Tree_Path(Safe_Str):                # File/dir path in tree entry
    max_length      = 4096                               # PATH_MAX on most systems
    allow_empty     = False                              # Tree entries must have names
    trim_whitespace = True
