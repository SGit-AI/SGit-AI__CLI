# ═══════════════════════════════════════════════════════════════════════════════
# List__Git__File_Changes - Type-safe list of Git file changes
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.type_safe_core.collections.Type_Safe__List import Type_Safe__List
from git_reader.schemas.Schema__Git__File_Change                      import Schema__Git__File_Change


class List__Git__File_Changes(Type_Safe__List):          # List of file changes
    expected_type = Schema__Git__File_Change
