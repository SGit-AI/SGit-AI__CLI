# ═══════════════════════════════════════════════════════════════════════════════
# Test__Git_Ref__Reader - Tests for Git reference reading
# Uses real git repository - no mocks
# ═══════════════════════════════════════════════════════════════════════════════

import unittest
from pathlib                                                                       import Path
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path  import Safe_Str__File__Path
from osbot_utils.type_safe.primitives.domains.git.safe_str.Safe_Str__Git__Branch   import Safe_Str__Git__Branch
from git_reader.Git_Ref__Reader                                                    import Git_Ref__Reader
from git_reader.schemas.Schema__Git__Branch                                        import Schema__Git__Branch


class test__Git_Ref__Reader(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.test_repo_path = cls.find_git_repo()
        cls.git_dir        = Safe_Str__File__Path(str(cls.test_repo_path / ".git"))
        cls.reader         = Git_Ref__Reader(git_dir=cls.git_dir)

    @classmethod
    def find_git_repo(cls) -> Path:
        current = Path(__file__).resolve()
        for parent in [current] + list(current.parents):
            if (parent / ".git").exists():
                return parent
        raise RuntimeError("No git repository found in parent directories")

    def test__init__(self):
        with Git_Ref__Reader() as _:
            assert type(_)              is Git_Ref__Reader
            assert _.git_dir            == ''

    def test__head_sha(self):
        sha = self.reader.head_sha()

        assert sha                      is not None
        assert type(sha)                is Safe_Str__SHA1
        assert len(str(sha))            == 40

    def test__branch_names(self):
        branches = self.reader.branch_names()

        assert type(branches)           is list
        assert len(branches)            > 0

        for branch in branches:
            assert type(branch)         is Safe_Str__Git__Branch
            assert str(branch)          != ''

    def test__branches(self):
        branches = self.reader.branches()

        assert type(branches)           is list
        assert len(branches)            > 0

        for branch in branches:
            assert type(branch)         is Schema__Git__Branch
            assert type(branch.name)    is Safe_Str__Git__Branch
            assert type(branch.commit_sha) is Safe_Str__SHA1
            assert len(str(branch.commit_sha)) == 40

    def test__branch_sha(self):
        branches = self.reader.branch_names()
        assert len(branches)            > 0

        first_branch = branches[0]
        sha          = self.reader.branch_sha(first_branch)

        assert sha                      is not None
        assert type(sha)                is Safe_Str__SHA1
        assert len(str(sha))            == 40

    def test__resolve_ref(self):
        branches = self.reader.branch_names()
        assert len(branches)            > 0

        first_branch = branches[0]
        ref_path     = f"refs/heads/{first_branch}"
        sha          = self.reader.resolve_ref(ref_path)

        assert sha                      is not None
        assert type(sha)                is Safe_Str__SHA1

    def test__read_packed_refs(self):
        packed_refs = self.reader.read_packed_refs()

        assert type(packed_refs)        is dict
        # packed-refs may or may not exist, but should not error

        for ref, sha in packed_refs.items():
            assert type(ref)            is str
            assert type(sha)            is Safe_Str__SHA1

    def test__head_sha__matches__branch(self):
        head_sha  = self.reader.head_sha()
        branches  = self.reader.branches()

        head_path = (self.test_repo_path / ".git" / "HEAD").read_text().strip()  # Check if HEAD points to a branch

        if head_path.startswith('ref: refs/heads/'):
            branch_name = head_path[16:]
            branch_sha  = self.reader.branch_sha(Safe_Str__Git__Branch(branch_name))
            assert str(head_sha)        == str(branch_sha)


if __name__ == '__main__':
    unittest.main()
