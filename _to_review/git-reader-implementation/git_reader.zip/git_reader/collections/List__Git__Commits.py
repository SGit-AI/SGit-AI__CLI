# ═══════════════════════════════════════════════════════════════════════════════
# List__Git__Commits - Type-safe list of Git commits
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.type_safe_core.collections.Type_Safe__List import Type_Safe__List
from git_reader.schemas.Schema__Git__Commit                           import Schema__Git__Commit


class List__Git__Commits(Type_Safe__List):               # List of commits
    expected_type = Schema__Git__Commit
