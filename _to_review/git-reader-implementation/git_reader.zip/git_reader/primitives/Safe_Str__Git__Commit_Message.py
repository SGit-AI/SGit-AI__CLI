# ═══════════════════════════════════════════════════════════════════════════════
# Safe_Str__Git__Commit_Message - Git commit message body
# Preserves formatting, allows up to 64KB
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.primitives.core.Safe_Str import Safe_Str


class Safe_Str__Git__Commit_Message(Safe_Str):           # Commit message body
    max_length      = 65536                              # 64KB - git allows large messages
    allow_empty     = True                               # Empty messages are valid
    trim_whitespace = False                              # Preserve message formatting!
