# ═══════════════════════════════════════════════════════════════════════════════
# List__Git__Branches - Type-safe list of Git branches
# ═══════════════════════════════════════════════════════════════════════════════

from osbot_utils.type_safe.type_safe_core.collections.Type_Safe__List import Type_Safe__List
from git_reader.schemas.Schema__Git__Branch                           import Schema__Git__Branch


class List__Git__Branches(Type_Safe__List):              # List of branches
    expected_type = Schema__Git__Branch
