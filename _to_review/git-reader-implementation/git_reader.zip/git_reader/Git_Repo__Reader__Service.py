# ═══════════════════════════════════════════════════════════════════════════════
# Git_Repo__Reader__Service - High-level Git repository reader
# Pure-Python implementation reading directly from .git folder
# ═══════════════════════════════════════════════════════════════════════════════

from pathlib                                                                       import Path
from typing                                                                        import Optional, List
from osbot_utils.type_safe.Type_Safe                                               import Type_Safe
from osbot_utils.type_safe.primitives.domains.cryptography.safe_str.Safe_Str__SHA1 import Safe_Str__SHA1
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path  import Safe_Str__File__Path
from osbot_utils.type_safe.primitives.domains.git.safe_str.Safe_Str__Git__Branch   import Safe_Str__Git__Branch
from git_reader.enums.Enum__Git__File_Change_Status                                import Enum__Git__File_Change_Status
from git_reader.enums.Enum__Git__Object_Type                                       import Enum__Git__Object_Type
from git_reader.schemas.Schema__Git__Branch                                        import Schema__Git__Branch
from git_reader.schemas.Schema__Git__Commit                                        import Schema__Git__Commit
from git_reader.schemas.Schema__Git__Commit_Summary                                import Schema__Git__Commit_Summary
from git_reader.schemas.Schema__Git__File_Change                                   import Schema__Git__File_Change
from git_reader.primitives.Safe_Str__Git__Tree_Path                                import Safe_Str__Git__Tree_Path
from git_reader.Git_Object__Reader                                                 import Git_Object__Reader
from git_reader.Git_Object__Parser                                                 import Git_Object__Parser
from git_reader.Git_Ref__Reader                                                    import Git_Ref__Reader


class Git_Repo__Reader__Service(Type_Safe):              # High-level Git repository API
    repo_path     : Safe_Str__File__Path                 # Path to repository root
    git_dir       : Safe_Str__File__Path                 # Path to .git folder
    object_reader : Git_Object__Reader                   # Low-level object reader
    object_parser : Git_Object__Parser                   # Object parser
    ref_reader    : Git_Ref__Reader                      # Reference reader

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.setup()

    def setup(self) -> 'Git_Repo__Reader__Service':
        if self.repo_path and not self.git_dir:          # Auto-detect .git folder
            git_path = Path(str(self.repo_path)) / ".git"
            if git_path.exists():
                self.git_dir = Safe_Str__File__Path(str(git_path))

        if self.git_dir:                                 # Initialize sub-components
            self.object_reader = Git_Object__Reader(git_dir = self.git_dir)
            self.ref_reader    = Git_Ref__Reader(git_dir = self.git_dir)
            self.object_parser = Git_Object__Parser(object_reader = self.object_reader)

        return self

    # ═══════════════════════════════════════════════════════════════════════════════
    # Branch Operations
    # ═══════════════════════════════════════════════════════════════════════════════

    def branches(self) -> List[Schema__Git__Branch]:
        return self.ref_reader.branches()

    def branch_names(self) -> List[Safe_Str__Git__Branch]:
        return self.ref_reader.branch_names()

    # ═══════════════════════════════════════════════════════════════════════════════
    # HEAD Operations
    # ═══════════════════════════════════════════════════════════════════════════════

    def head_sha(self) -> Optional[Safe_Str__SHA1]:
        return self.ref_reader.head_sha()

    def head_commit(self) -> Optional[Schema__Git__Commit_Summary]:
        sha = self.head_sha()
        if sha is None:
            return None

        commit = self.commit(sha)
        if commit is None:
            return None

        files_changed = self.files_changed(sha)

        return Schema__Git__Commit_Summary(commit        = commit       ,
                                           files_changed = files_changed)

    # ═══════════════════════════════════════════════════════════════════════════════
    # Commit Operations
    # ═══════════════════════════════════════════════════════════════════════════════

    def commit(self, sha: Safe_Str__SHA1) -> Optional[Schema__Git__Commit]:
        result = self.object_reader.read_object(sha)
        if result is None:
            return None

        obj_type, content = result

        if obj_type != Enum__Git__Object_Type.COMMIT:
            return None

        return self.object_parser.parse_commit(sha, content)

    def commits(self                                   ,
                branch : Safe_Str__Git__Branch = None  ,
                sha    : Safe_Str__SHA1        = None  ,
                depth  : int                   = 10    ) -> List[Schema__Git__Commit]:
        if sha is None:
            if branch:
                sha = self.ref_reader.branch_sha(branch)
            else:
                sha = self.head_sha()

        if sha is None:
            return []

        result  = []
        current = sha

        for _ in range(depth):
            commit = self.commit(current)
            if commit is None:
                break

            result.append(commit)

            if len(commit.parent_shas) == 0:             # Reached initial commit
                break

            current = commit.parent_shas[0]              # Follow first parent

        return result

    # ═══════════════════════════════════════════════════════════════════════════════
    # File Change Detection
    # ═══════════════════════════════════════════════════════════════════════════════

    def files_changed(self, sha: Safe_Str__SHA1) -> List[Schema__Git__File_Change]:
        commit = self.commit(sha)
        if commit is None:
            return []

        current_files = self.object_parser.flatten_tree(commit.tree_sha)

        if len(commit.parent_shas) == 0:                 # Initial commit: all added
            return [Schema__Git__File_Change(path   = Safe_Str__Git__Tree_Path(path),
                                             status = Enum__Git__File_Change_Status.ADDED)
                    for path in sorted(current_files.keys())]

        parent       = self.commit(commit.parent_shas[0])
        if parent is None:
            return []

        parent_files = self.object_parser.flatten_tree(parent.tree_sha)
        changes      = []

        for path, blob_sha in current_files.items():     # Added and modified
            if path not in parent_files:
                changes.append(Schema__Git__File_Change(path   = Safe_Str__Git__Tree_Path(path),
                                                        status = Enum__Git__File_Change_Status.ADDED))
            elif str(parent_files[path]) != str(blob_sha):
                changes.append(Schema__Git__File_Change(path   = Safe_Str__Git__Tree_Path(path),
                                                        status = Enum__Git__File_Change_Status.MODIFIED))

        for path in parent_files:                        # Deleted
            if path not in current_files:
                changes.append(Schema__Git__File_Change(path   = Safe_Str__Git__Tree_Path(path),
                                                        status = Enum__Git__File_Change_Status.DELETED))

        return changes
